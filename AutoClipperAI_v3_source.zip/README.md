# AutoClipper AI v3

Versi ini memperbaiki dua masalah v2:

1. Tidak lagi hard-code `gemini-2.5-flash` untuk pengecekan API. Aplikasi meminta daftar model yang tersedia untuk key, lalu memilih model yang mendukung `generateContent`.
2. Backend URL dapat diganti dari aplikasi. HP fisik harus memakai IP LAN backend, sedangkan `10.0.2.2` hanya untuk Android Emulator.

Fitur:
- Simpan beberapa Gemini API key secara terenkripsi menggunakan Android Keystore.
- Cek akses key, model yang tersedia, dan rate-limit.
- Rotasi key saat analisis jika key gagal/rate-limited.
- Download audio YouTube dengan yt-dlp.
- Transkripsi bertimestamp dengan Faster-Whisper.
- Pemrosesan video panjang dengan transcript chunking.
- Gemini memilih kandidat clip.
- Download video hanya saat user meminta clip; video disimpan dalam job untuk clip berikutnya.
- FFmpeg membuat MP4.

## Build APK di GitHub Actions

Workflow menggunakan Gradle 8.9 karena project membutuhkan minimal Gradle 8.9.

Setelah repo berisi project ini, buka Actions dan jalankan `Build AutoClipper AI v3`.
