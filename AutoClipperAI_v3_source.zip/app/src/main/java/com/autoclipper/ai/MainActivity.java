package com.autoclipper.ai;

import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import org.json.*;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

public class MainActivity extends Activity {
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private static final String PREFS="autoclipper_v3";
    private static final String KEY_ALIAS="AutoClipperAIKeyStore";
    private SharedPreferences prefs;
    private LinearLayout root, keyList, resultButtons;
    private EditText backend, youtube, keyInput, durInput, countInput;
    private TextView status, result, quotaInfo;
    private ProgressBar progress;
    private String lastJobId="";

    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView tv(String s,float size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(235,230,240));t.setPadding(dp(4),dp(5),dp(4),dp(5));return t;}
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}

    @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences(PREFS,MODE_PRIVATE);buildUi();}

    private void buildUi(){
        ScrollView sv=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(18),dp(18),dp(28));root.setBackgroundColor(Color.rgb(18,15,23));sv.addView(root);setContentView(sv);
        TextView title=tv("AutoClipper AI v3",30);title.setTypeface(null,1);title.setTextColor(Color.WHITE);root.addView(title);
        root.addView(tv("YouTube → transkripsi → Gemini pilih momen → buat clip",16));

        root.addView(tv("Backend URL",18));
        backend=new EditText(this);backend.setSingleLine(true);backend.setHint("http://192.168.1.5:8000");backend.setText(prefs.getString("backend","http://10.0.2.2:8000"));root.addView(backend);
        Button health=btn("🔌 Tes koneksi backend");root.addView(health);health.setOnClickListener(v->testBackend());

        root.addView(tv("Gemini API Keys",18));
        root.addView(tv("Key disimpan lokal. Cek kuota menampilkan status akses/rate-limit; Google tidak menyediakan angka sisa quota umum dari endpoint ini.",12));
        keyList=new LinearLayout(this);keyList.setOrientation(LinearLayout.VERTICAL);root.addView(keyList);
        keyInput=new EditText(this);keyInput.setSingleLine(true);keyInput.setHint("AIza...");root.addView(keyInput);
        LinearLayout row=new LinearLayout(this);Button add=btn("+ Tambah Key");Button check=btn("Cek Key & Kuota");row.addView(add,new LinearLayout.LayoutParams(0,dp(52),1));row.addView(check,new LinearLayout.LayoutParams(0,dp(52),1));root.addView(row);
        add.setOnClickListener(v->addKey());check.setOnClickListener(v->checkKeys());refreshKeys();
        quotaInfo=tv("",13);root.addView(quotaInfo);

        root.addView(tv("YouTube URL",18));youtube=new EditText(this);youtube.setSingleLine(true);youtube.setHint("https://www.youtube.com/watch?v=...");root.addView(youtube);
        root.addView(tv("Durasi clip (detik)",18));durInput=new EditText(this);durInput.setSingleLine(true);durInput.setInputType(2);durInput.setText("45");root.addView(durInput);
        root.addView(tv("Jumlah clip",18));countInput=new EditText(this);countInput.setSingleLine(true);countInput.setInputType(2);countInput.setText("5");root.addView(countInput);
        Button analyze=btn("✨ ANALISIS VIDEO YOUTUBE");root.addView(analyze);
        progress=new ProgressBar(this);progress.setVisibility(View.GONE);root.addView(progress);
        status=tv("Siap.",15);root.addView(status);root.addView(tv("Hasil AI",22));result=tv("",16);root.addView(result);resultButtons=new LinearLayout(this);resultButtons.setOrientation(LinearLayout.VERTICAL);root.addView(resultButtons);
        analyze.setOnClickListener(v->{prefs.edit().putString("backend",backend.getText().toString().trim()).apply();String u=youtube.getText().toString().trim();if(u.isEmpty()){toast("Masukkan URL YouTube");return;}int d=parseInt(durInput.getText().toString(),45);int c=parseInt(countInput.getText().toString(),5);if(d<15||d>600){toast("Durasi clip: 15–600 detik");return;}if(c<1||c>30){toast("Jumlah clip: 1–30");return;}analyze(u,d,c);});
    }

    private int parseInt(String s,int def){try{return Integer.parseInt(s.trim());}catch(Exception e){return def;}}
    private String base(){String b=backend.getText().toString().trim();while(b.endsWith("/"))b=b.substring(0,b.length()-1);return b;}

    private JSONArray loadKeys(){try{return new JSONArray(decrypt(prefs.getString("keys_enc","")));}catch(Exception e){return new JSONArray();}}
    private void saveKeys(JSONArray a){prefs.edit().putString("keys_enc",encrypt(a.toString())).apply();}

    private void refreshKeys(){keyList.removeAllViews();JSONArray a=loadKeys();for(int i=0;i<a.length();i++){try{final int idx=i;JSONObject o=a.getJSONObject(i);LinearLayout r=new LinearLayout(this);String st=o.optString("status","NOT_CHECKED");TextView t=tv(mask(o.optString("key"))+"  ["+st+"]",14);Button del=btn("Hapus");r.addView(t,new LinearLayout.LayoutParams(0,dp(48),1));r.addView(del,new LinearLayout.LayoutParams(dp(80),dp(48)));del.setOnClickListener(v->{JSONArray x=loadKeys();x.remove(idx);saveKeys(x);refreshKeys();});keyList.addView(r);}catch(Exception ignored){}}}
    private String mask(String k){if(k.length()<=10)return k;return k.substring(0,6)+"••••••"+k.substring(k.length()-4);}

    private void addKey(){String k=keyInput.getText().toString().trim();if(k.isEmpty()){toast("API key kosong");return;}JSONArray a=loadKeys();for(int i=0;i<a.length();i++)if(k.equals(a.optJSONObject(i).optString("key"))){toast("Key sudah ada");return;}try{JSONObject o=new JSONObject();o.put("key",k);o.put("status","NOT_CHECKED");o.put("model","");a.put(o);saveKeys(a);keyInput.setText("");refreshKeys();}catch(Exception e){toast(e.toString());}}

    private void checkKeys(){
        new Thread(()->{JSONArray a=loadKeys();int valid=0,limited=0;for(int i=0;i<a.length();i++){try{JSONObject o=a.getJSONObject(i);GeminiCheck gc=geminiCheck(o.optString("key"));o.put("status",gc.status);o.put("model",gc.model);o.put("checked",System.currentTimeMillis());if("VALID".equals(gc.status))valid++;if("RATE_LIMITED".equals(gc.status))limited++;}catch(Exception e){}}saveKeys(a);int v=valid,l=limited;runOnUiThread(()->{refreshKeys();quotaInfo.setText("Hasil: "+v+" key VALID, "+l+" rate-limited. Angka quota tersisa tidak tersedia secara umum.");toast("Pengecekan selesai");});}).start();
    }

    private static class GeminiCheck{String status,model;GeminiCheck(String s,String m){status=s;model=m;}}
    private GeminiCheck geminiCheck(String key){
        try{
            HttpResult models=httpGet("https://generativelanguage.googleapis.com/v1beta/models?key="+URLEncoder.encode(key,"UTF-8"),30000);
            if(models.code==401||models.code==403)return new GeminiCheck("INVALID","");
            if(models.code==429)return new GeminiCheck("RATE_LIMITED","");
            if(models.code==404)return new GeminiCheck("NO_MODEL","");
            if(models.code>=400)return new GeminiCheck("ERROR_"+models.code,"");
            JSONObject root=new JSONObject(models.body);JSONArray ms=root.optJSONArray("models");String chosen="";
            for(int i=0;i<(ms==null?0:ms.length());i++){JSONObject m=ms.getJSONObject(i);JSONArray methods=m.optJSONArray("supportedGenerationMethods");boolean gen=false;for(int j=0;j<(methods==null?0:methods.length());j++)if("generateContent".equals(methods.getString(j)))gen=true;if(!gen)continue;String n=m.optString("name");if(n.contains("gemini-2.5-flash")){chosen=n;break;}if(chosen.isEmpty()&&n.contains("gemini-2.0-flash"))chosen=n;if(chosen.isEmpty())chosen=n;}
            if(chosen.isEmpty())return new GeminiCheck("NO_MODEL","");
            String endpoint="https://generativelanguage.googleapis.com/v1beta/"+chosen+":generateContent?key="+URLEncoder.encode(key,"UTF-8");
            String body="{\"contents\":[{\"parts\":[{\"text\":\"Reply only OK\"}]}]}";HttpResult r=httpPost(endpoint,body,30000);
            if(r.code==200)return new GeminiCheck("VALID",chosen.replace("models/",""));
            if(r.code==429)return new GeminiCheck("RATE_LIMITED",chosen.replace("models/",""));
            if(r.code==401||r.code==403)return new GeminiCheck("INVALID",chosen.replace("models/",""));
            if(r.code==404)return new GeminiCheck("NO_MODEL",chosen.replace("models/",""));
            return new GeminiCheck("ERROR_"+r.code,chosen.replace("models/",""));
        }catch(Exception e){return new GeminiCheck("NETWORK_ERROR","");}
    }

    private void testBackend(){pool.submit(()->{try{HttpResult r=httpGet(base()+"/api/health",15000);runOnUiThread(()->toast(r.code==200?"Backend terhubung":"Backend HTTP "+r.code));}catch(Exception e){runOnUiThread(()->toast("Gagal konek: "+e.getMessage()));}});}

    private void analyze(String url,int duration,int count){progress.setVisibility(View.VISIBLE);status.setText("Backend mengunduh audio & transkripsi. Video 1 jam+ bisa beberapa menit...");result.setText("");resultButtons.removeAllViews();pool.submit(()->{try{JSONArray keys=loadKeys();if(keys.length()==0)throw new Exception("Tambahkan minimal 1 Gemini API Key");JSONObject req=new JSONObject();req.put("youtube_url",url);req.put("clip_duration",duration);req.put("clip_count",count);req.put("gemini_api_keys",keysToString(keys));String r=post(base()+"/api/analyze",req.toString(),900000);JSONObject o=new JSONObject(r);lastJobId=o.optString("job_id","");runOnUiThread(()->{progress.setVisibility(View.GONE);status.setText("Analisis selesai. Job: "+lastJobId);showResult(r);});}catch(Exception e){runOnUiThread(()->{progress.setVisibility(View.GONE);status.setText("Gagal: "+e.getMessage());});}});}
    private JSONArray keysToString(JSONArray a){JSONArray out=new JSONArray();for(int i=0;i<a.length();i++){String k=a.optJSONObject(i).optString("key");if(!k.isEmpty())out.put(k);}return out;}

    private void showResult(String raw){try{JSONObject o=new JSONObject(raw);JSONArray clips=o.optJSONArray("clips");if(clips==null){result.setText(raw);return;}result.setText("Ditemukan "+clips.length()+" kandidat dari video panjang.\n\n");for(int i=0;i<clips.length();i++){JSONObject c=clips.getJSONObject(i);result.append("#"+(i+1)+" "+c.optString("title","Clip")+"\n");result.append(c.optString("start")+" → "+c.optString("end")+" • "+c.optInt("score",0)+"/100\n");result.append(c.optString("reason","")+"\n\n");Button b=btn("✂ BUAT CLIP MP4");final JSONObject clip=c;b.setOnClickListener(v->makeClip(clip));resultButtons.addView(b);}}catch(Exception e){result.setText(raw);}}

    private void makeClip(JSONObject clip){pool.submit(()->{try{JSONObject req=new JSONObject();req.put("job_id",lastJobId);req.put("youtube_url",youtube.getText().toString().trim());req.put("start",clip.optString("start"));req.put("end",clip.optString("end"));String r=post(base()+"/api/clip",req.toString(),900000);JSONObject o=new JSONObject(r);String dl=o.optString("download","");runOnUiThread(()->{Button b=btn("⬇ BUKA / DOWNLOAD CLIP");b.setOnClickListener(v->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(base()+dl))));resultButtons.addView(b);toast("Clip selesai");});}catch(Exception e){runOnUiThread(()->toast("Clip gagal: "+e.getMessage()));}});}

    private static class HttpResult{int code;String body;HttpResult(int c,String b){code=c;body=b;}}
    private HttpResult httpGet(String u,int timeout)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(timeout);c.setReadTimeout(timeout);int code=c.getResponseCode();InputStream is=code>=400?c.getErrorStream():c.getInputStream();String body=is==null?"":readStream(is);c.disconnect();return new HttpResult(code,body);}
    private HttpResult httpPost(String u,String body,int timeout)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(timeout);c.setReadTimeout(timeout);c.setRequestProperty("Content-Type","application/json");c.setDoOutput(true);try(OutputStream os=c.getOutputStream()){os.write(body.getBytes(StandardCharsets.UTF_8));}int code=c.getResponseCode();InputStream is=code>=400?c.getErrorStream():c.getInputStream();String out=is==null?"":readStream(is);c.disconnect();return new HttpResult(code,out);}
    private String post(String u,String body,int timeout)throws Exception{HttpResult r=httpPost(u,body,timeout);if(r.code>=400)throw new IOException("HTTP "+r.code+": "+r.body);return r.body;}

    private SecretKey secretKey()throws Exception{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(!ks.containsAlias(KEY_ALIAS)){KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());kg.generateKey();}return ((KeyStore.SecretKeyEntry)ks.getEntry(KEY_ALIAS,null)).getSecretKey();}
    private String encrypt(String plain){try{byte[] iv=new byte[12];new SecureRandom().nextBytes(iv);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,secretKey(),new GCMParameterSpec(128,iv));byte[] enc=c.doFinal(plain.getBytes(StandardCharsets.UTF_8));return android.util.Base64.encodeToString(iv, android.util.Base64.NO_WRAP)+":"+android.util.Base64.encodeToString(enc, android.util.Base64.NO_WRAP);}catch(Exception e){return "";}}
    private String decrypt(String packed){if(packed==null||packed.isEmpty())return "[]";try{String[] p=packed.split(":",2);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,secretKey(),new GCMParameterSpec(128,android.util.Base64.decode(p[0], android.util.Base64.DEFAULT)));return new String(c.doFinal(android.util.Base64.decode(p[1], android.util.Base64.DEFAULT)),StandardCharsets.UTF_8);}catch(Exception e){return "[]";}}
    private String readStream(InputStream is)throws Exception{if(is==null)return "";ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=is.read(buf))!=-1)b.write(buf,0,n);return new String(b.toByteArray(),StandardCharsets.UTF_8);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
