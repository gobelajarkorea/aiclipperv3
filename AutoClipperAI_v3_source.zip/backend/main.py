import json
import os
import re
import shutil
import subprocess
import uuid
from pathlib import Path
from typing import List

import requests
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

try:
    from faster_whisper import WhisperModel
except Exception:
    WhisperModel = None

app = FastAPI(title="AutoClipper AI Backend v3")
BASE = Path(__file__).resolve().parent
WORK = BASE / "work"
WORK.mkdir(exist_ok=True)

GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta"
WHISPER_MODEL = os.getenv("WHISPER_MODEL", "small")
MAX_GEMINI_CHUNKS = int(os.getenv("MAX_GEMINI_CHUNKS", "8"))

_whisper = None

class AnalyzeReq(BaseModel):
    youtube_url: str
    clip_duration: int = Field(default=45, ge=15, le=600)
    clip_count: int = Field(default=5, ge=1, le=30)
    gemini_api_keys: List[str] = Field(default_factory=list)

class ClipReq(BaseModel):
    job_id: str
    youtube_url: str = ""
    start: str
    end: str

@app.get("/api/health")
def health():
    return {
        "ok": True,
        "service": "AutoClipper AI v3",
        "whisper_model": WHISPER_MODEL,
        "ffmpeg": shutil.which("ffmpeg") is not None,
        "yt_dlp": shutil.which("yt-dlp") is not None,
    }

def run(cmd, timeout):
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError(p.stderr[-5000:] or "Command gagal")
    return p

def download_audio(url: str, job: Path) -> Path:
    out = str(job / "audio.%(ext)s")
    run(["yt-dlp", "--no-playlist", "-x", "--audio-format", "mp3", "-o", out, url], 7200)
    mp3 = job / "audio.mp3"
    if not mp3.exists():
        found = list(job.glob("audio.*"))
        if not found:
            raise RuntimeError("Audio tidak ditemukan setelah yt-dlp")
        return found[0]
    return mp3

def get_whisper():
    global _whisper
    if WhisperModel is None:
        raise RuntimeError("faster-whisper belum terpasang. Jalankan pip install -r requirements.txt")
    if _whisper is None:
        device = os.getenv("WHISPER_DEVICE", "cpu")
        compute = os.getenv("WHISPER_COMPUTE", "int8")
        _whisper = WhisperModel(WHISPER_MODEL, device=device, compute_type=compute)
    return _whisper

def transcribe(audio: Path, job: Path):
    model = get_whisper()
    segments, info = model.transcribe(str(audio), beam_size=5, vad_filter=True, condition_on_previous_text=True)
    rows = []
    for s in segments:
        text = (s.text or "").strip()
        if text:
            rows.append({"start": float(s.start), "end": float(s.end), "text": text})
    if not rows:
        raise RuntimeError("Transkripsi kosong")
    (job / "transcript.json").write_text(json.dumps({"language": info.language, "segments": rows}, ensure_ascii=False), encoding="utf-8")
    return rows, info.language

def fmt_time(sec: float) -> str:
    sec = max(0, int(round(sec)))
    h, sec = divmod(sec, 3600)
    m, s = divmod(sec, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"

def build_chunks(rows, max_chunks=8):
    if not rows:
        return []
    total_end = rows[-1]["end"]
    chunk_len = max(300, total_end / max_chunks)
    chunks = []
    start = 0.0
    while start < total_end and len(chunks) < max_chunks:
        end = min(total_end, start + chunk_len)
        parts = [f"[{fmt_time(x['start'])} - {fmt_time(x['end'])}] {x['text']}" for x in rows if x["end"] >= start and x["start"] < end]
        if parts:
            chunks.append({"start": start, "end": end, "text": "\n".join(parts)})
        start = end
    return chunks

def list_models(key: str):
    r = requests.get(f"{GEMINI_BASE}/models", headers={"x-goog-api-key": key}, timeout=30)
    if r.status_code != 200:
        raise RuntimeError(f"MODEL_LIST_{r.status_code}: {r.text[-1000:]}")
    data = r.json()
    models = []
    for m in data.get("models", []):
        if "generateContent" in m.get("supportedGenerationMethods", []):
            models.append(m.get("name", ""))
    # Prefer current Flash models, then older stable/preview models.
    priority = [
        "models/gemini-3.6-flash",
        "models/gemini-3.5-flash",
        "models/gemini-3.5-flash-lite",
        "models/gemini-3.1-flash-lite",
        "models/gemini-3-flash-preview",
        "models/gemini-2.5-flash",
        "models/gemini-2.0-flash",
    ]
    for p in priority:
        if p in models:
            return p
    for m in models:
        if "flash" in m.lower() and "image" not in m.lower():
            return m
    return models[0] if models else None

def gemini_call(key: str, model: str, transcript: str, clip_duration: int, clip_count: int):
    prompt = f"""You are a professional short-form YouTube editor.
Analyze this timestamped transcript section and find the strongest moments for short clips.
Requested clip length: about {clip_duration} seconds.
Return ONLY valid JSON, no markdown:
{{"clips":[{{"title":"...","start":"HH:MM:SS","end":"HH:MM:SS","score":0,"reason":"..."}}]}}
Rules:
- Pick moments that have a strong hook, conflict, surprise, useful insight, humor, emotion, or payoff.
- Keep start/end inside the supplied transcript section.
- Aim for {max(1, min(4, clip_count))} candidates from this section.
- Do not invent timestamps.
- Score 0-100.
Transcript section:
{transcript}
"""
    url = f"{GEMINI_BASE}/{model}:generateContent"
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.2, "responseMimeType": "application/json"},
    }
    r = requests.post(url, headers={"x-goog-api-key": key, "Content-Type": "application/json"}, json=body, timeout=180)
    if r.status_code != 200:
        raise RuntimeError(f"GEMINI_{r.status_code}: {r.text[-1500:]}")
    data = r.json()
    text = "".join(p.get("text", "") for p in data.get("candidates", [{}])[0].get("content", {}).get("parts", []))
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise RuntimeError("Gemini tidak mengembalikan JSON")
    return json.loads(m.group(0)).get("clips", [])

def valid_time(s: str) -> int:
    parts = s.strip().split(":")
    if len(parts) == 2:
        return int(parts[0]) * 60 + int(parts[1])
    if len(parts) == 3:
        return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
    raise ValueError("format waktu tidak valid")

def normalize_candidates(candidates, duration):
    out = []
    for c in candidates:
        try:
            st = valid_time(c.get("start", ""))
            en = valid_time(c.get("end", ""))
            if en <= st:
                continue
            # Force roughly requested duration while keeping the center of the AI-selected moment.
            if en - st > duration * 1.35:
                center = (st + en) / 2
                st = max(0, int(center - duration / 2))
                en = st + duration
            elif en - st < max(12, duration * 0.45):
                en = st + duration
            c["start"] = fmt_time(st)
            c["end"] = fmt_time(en)
            c["score"] = max(0, min(100, int(c.get("score", 0))))
            out.append(c)
        except Exception:
            continue
    out.sort(key=lambda x: x.get("score", 0), reverse=True)
    chosen = []
    for c in out:
        a, b = valid_time(c["start"]), valid_time(c["end"])
        overlap = False
        for x in chosen:
            x1, x2 = valid_time(x["start"]), valid_time(x["end"])
            inter = max(0, min(b, x2) - max(a, x1))
            if inter > 0.35 * min(b - a, x2 - x1):
                overlap = True
                break
        if not overlap:
            chosen.append(c)
    return chosen

def gemini_analyze(keys, chunks, duration, count):
    if not keys:
        raise RuntimeError("Tidak ada Gemini API key")
    candidates = []
    key_index = 0
    models_cache = {}
    errors = []
    for idx, ch in enumerate(chunks):
        success = False
        attempts = 0
        while attempts < len(keys):
            key = keys[key_index % len(keys)]
            key_index += 1
            attempts += 1
            try:
                model = models_cache.get(key)
                if not model:
                    model = list_models(key)
                    if not model:
                        raise RuntimeError("NO_MODEL")
                    models_cache[key] = model
                got = gemini_call(key, model, ch["text"], duration, count)
                candidates.extend(got)
                success = True
                break
            except Exception as e:
                msg = str(e)
                errors.append(msg[:180])
                # Rotate on quota/rate-limit/auth/model errors; other errors also get one rotation.
                continue
        if not success:
            continue
    final = normalize_candidates(candidates, duration)[:count]
    if not final:
        detail = "; ".join(errors[:5])
        raise RuntimeError("Tidak ada kandidat clip. " + detail)
    return final, models_cache

def ensure_video(job: Path, youtube_url: str):
    video = job / "source.mp4"
    if video.exists() and video.stat().st_size > 1_000_000:
        return video
    run(["yt-dlp", "--no-playlist", "-f", "bv*+ba/b", "--merge-output-format", "mp4", "-o", str(video), youtube_url], 7200)
    if not video.exists():
        raise RuntimeError("Video tidak ditemukan setelah yt-dlp")
    return video

@app.post("/api/analyze")
def analyze(req: AnalyzeReq):
    job = WORK / uuid.uuid4().hex
    job.mkdir(parents=True)
    try:
        audio = download_audio(req.youtube_url, job)
        rows, language = transcribe(audio, job)
        chunks = build_chunks(rows, MAX_GEMINI_CHUNKS)
        clips, models = gemini_analyze(req.gemini_api_keys, chunks, req.clip_duration, req.clip_count)
        (job / "meta.json").write_text(json.dumps({"youtube_url": req.youtube_url, "language": language, "models": models}, ensure_ascii=False), encoding="utf-8")
        return {"ok": True, "job_id": job.name, "language": language, "duration_seconds": rows[-1]["end"], "clips": clips, "gemini_models": list(set(models.values()))}
    except Exception as e:
        raise HTTPException(500, str(e))

@app.post("/api/clip")
def clip(req: ClipReq):
    try:
        job = WORK / Path(req.job_id).name
        if not job.exists():
            raise HTTPException(404, "Job tidak ditemukan")
        meta_file = job / "meta.json"
        youtube_url = req.youtube_url
        if meta_file.exists():
            try:
                youtube_url = json.loads(meta_file.read_text(encoding="utf-8")).get("youtube_url") or youtube_url
            except Exception:
                pass
        if not youtube_url:
            raise HTTPException(400, "URL YouTube tidak tersedia")
        video = ensure_video(job, youtube_url)
        start = valid_time(req.start); end = valid_time(req.end)
        if end <= start:
            raise HTTPException(400, "Rentang waktu tidak valid")
        out = job / f"clip_{start}_{end}.mp4"
        run(["ffmpeg", "-y", "-ss", str(start), "-i", str(video), "-t", str(end-start), "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-c:a", "aac", "-movflags", "+faststart", str(out)], 1800)
        return {"ok": True, "download": f"/api/download/{job.name}/{out.name}"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, str(e))

@app.get("/api/download/{job}/{name}")
def download(job: str, name: str):
    safe_job = Path(job).name
    safe_name = Path(name).name
    p = WORK / safe_job / safe_name
    if not p.exists() or not p.is_file():
        raise HTTPException(404, "File tidak ditemukan")
    return FileResponse(p, media_type="video/mp4", filename=safe_name)
